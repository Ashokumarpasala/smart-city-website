//.....Ternary Operator
let age = 20;
// variable = condition ? Exp1 : Exp2 ;
let voter = (age >= 18) ? 'Eligible to Vote' : 'Not Eligible to Vote';

console.log(voter); // Output: 'Eligible to Vote'
